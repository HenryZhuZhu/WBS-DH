# DE-WBS

## 设备采购与研发就绪原型

- [打开单文件交互原型](Equipment-WBS-prototype.html)
- [客户演示说明](Equipment-WBS-DEMO.md)
- [项目上下文与已确认规则](CONTEXT.md)

将 HTML 文件直接用桌面浏览器打开即可使用，无远程字体或脚本依赖。数据保存在当前浏览器；右上角问号中可恢复演示数据。

## 原有设计 Block WBS

- [原有交互原型](DE-WBS-prototype-v1.html)
- [原有开发 PRD](DE-WBS-development-PRD.md)

原有文件保留；设备采购业务原型独立交付，复用原有视觉与交互语言。
