# Repository Guidelines

## Project Structure & Module Organization

- `WBS-main/Equipment-WBS-prototype.html` is the active WBS-DH prototype. HTML, CSS, JavaScript, demo data, and icons are inline; there is no backend or separate asset pipeline.
- `WBS-main/CONTEXT.md` records business decisions chronologically. Read the latest entries first when older descriptions conflict.
- `WBS-main/Equipment-WBS-DEMO.md` describes demonstration flows; `README.md` provides entry points.
- `DE-WBS-prototype-v1.html`, `DE-WBS-development-PRD.md`, and ZIP snapshots are legacy references. Preserve them when updating the active prototype.

## Build, Test, and Development Commands

Run from the repository root:

```sh
python3 -m http.server 8765 --bind 127.0.0.1 --directory WBS-main
```

Open `http://127.0.0.1:8765/Equipment-WBS-prototype.html` to preview. Keep the server running while reviewing. Direct desktop-browser opening also works, but browser storage depends on the origin.

```sh
curl -I http://127.0.0.1:8765/Equipment-WBS-prototype.html
```

This checks HTTP availability only. There is no build step, package manifest, configured linter, or automated test command.

## Coding Style & Naming Conventions

Match surrounding code and avoid wholesale reformatting. Use two-space indentation for new expanded blocks, camelCase JavaScript identifiers, and kebab-case CSS classes. Reuse existing styles, escaping helpers, shared state, and rendering functions. Keep overview totals, table cells, and detail drawers derived from the same data.

## Testing Guidelines

No checked-in test framework or coverage threshold exists. Manually verify affected desktop flows: navigation, column resizing and filtering, dropdown edits, single-date PO entry, detail synchronization, and persistence after refresh. For calculation changes, check decimal precision and zero-total percentages. Confirm problem links open the correct problem and milestone status remains Leader-maintained. Report actual checks and any untested behavior.

## Product & Data Constraints

Use the name WBS-DH. Design for desktop only; use system fonts, never Google Fonts. Preserve one WBS master table and the Leader perspective without a role switcher. Workstation details show existing row fields only. Preserve localStorage data and modification history; use fictional procurement data. Update context and demo documentation when behavior changes.

## Commit & Pull Request Guidelines

This workspace has no available Git history, so no existing commit convention can be verified. Use focused imperative subjects, such as `Fix milestone detail synchronization`. PRs should describe behavior changes, reference relevant issues when available, record validation, and include screenshots for visual changes.
